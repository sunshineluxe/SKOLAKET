import React, { useState, useEffect } from 'react';
import { 
  Camera, 
  Bell, 
  ShoppingCart, 
  Search,
  Filter,
  Grid,
  Home,
  Compass,
  MessageSquare,
  User,
  ArrowUp,
  Pipette as Swipe,
  Book,
  Utensils,
  Shirt,
  Laptop,
  Sofa,
  Car,
  Gamepad,
  Music,
  Palette,
  Dumbbell,
  Building,
  GraduationCap,
  Briefcase,
  Heart,
  Smartphone
} from 'lucide-react';

const locations = ['UCC', 'KNUST', 'UG', 'UPSA', 'UMaT'];

const categories = [
  { name: 'Books', icon: Book, color: 'bg-blue-400' },
  { name: 'Food', icon: Utensils, color: 'bg-orange-400' },
  { name: 'Fashion', icon: Shirt, color: 'bg-pink-400' },
  { name: 'Electronics', icon: Laptop, color: 'bg-purple-400' },
  { name: 'Furniture', icon: Sofa, color: 'bg-yellow-400' },
  { name: 'Vehicles', icon: Car, color: 'bg-red-400' },
  { name: 'Gaming', icon: Gamepad, color: 'bg-green-400' },
  { name: 'Music', icon: Music, color: 'bg-indigo-400' },
  { name: 'Art', icon: Palette, color: 'bg-teal-400' },
  { name: 'Sports', icon: Dumbbell, color: 'bg-cyan-400' },
  { name: 'Housing', icon: Building, color: 'bg-rose-400' },
  { name: 'Academic', icon: GraduationCap, color: 'bg-emerald-400' },
  { name: 'Jobs', icon: Briefcase, color: 'bg-violet-400' },
  { name: 'Health', icon: Heart, color: 'bg-fuchsia-400' },
  { name: 'Mobile', icon: Smartphone, color: 'bg-amber-400' }
];

const banners = [
  {
    title: 'WELCOME TO SCHOLARKET',
    subtitle: 'Your Campus Marketplace',
    image: 'https://images.unsplash.com/photo-1523050854058-8df90110c9f1?w=1200'
  },
  {
    title: 'SELL YOUR ITEMS',
    subtitle: 'Turn Your Items into Cash',
    image: 'https://images.unsplash.com/photo-1472851294608-062f824d29cc?w=1200'
  },
  {
    title: 'GREAT DEALS DAILY',
    subtitle: 'Find Amazing Campus Offers',
    image: 'https://images.unsplash.com/photo-1541339907198-e08756dedf3f?w=1200'
  }
];

const topSellers = [
  {
    id: 'seller1',
    name: 'John Doe',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100',
    verified: true,
    location: 'UCC',
    rating: 4.8,
    sales: 156
  },
  {
    id: 'seller2',
    name: 'Sarah Smith',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100',
    verified: true,
    location: 'KNUST',
    rating: 4.9,
    sales: 203
  },
  {
    id: 'seller3',
    name: 'Mike Johnson',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100',
    verified: true,
    location: 'UG',
    rating: 4.7,
    sales: 178
  }
];

const allProducts = {
  'Top Products': [
    {
      id: 1,
      name: 'Gray Sweatshirt',
      price: 'GHC 300',
      location: 'UCC',
      image: 'https://images.unsplash.com/photo-1578587018452-892bacefd3f2?w=400',
      verified: true,
      sold: 12,
      rating: 4.5,
      seller: topSellers[0]
    },
    {
      id: 2,
      name: 'Hockey Jersey',
      price: 'GHC 300',
      location: 'KNUST',
      image: 'https://images.unsplash.com/photo-1580674285054-bed31e145f59?w=400',
      verified: true,
      sold: 31,
      rating: 4.5,
      seller: topSellers[1]
    }
  ],
  'Best Sellers': [
    {
      id: 3,
      name: 'Study Desk',
      price: 'GHC 450',
      location: 'UCC',
      image: 'https://images.unsplash.com/photo-1518455027359-f3f8164ba6bd?w=400',
      verified: true,
      sold: 45,
      rating: 4.8,
      seller: topSellers[2]
    },
    {
      id: 4,
      name: 'Textbook Set',
      price: 'GHC 200',
      location: 'KNUST',
      image: 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=400',
      verified: true,
      sold: 67,
      rating: 4.7,
      seller: topSellers[0]
    }
  ],
  'Promos & Disc': [
    {
      id: 5,
      name: 'Laptop Bag',
      price: 'GHC 150',
      originalPrice: 'GHC 250',
      location: 'UCC',
      image: 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=400',
      verified: true,
      sold: 8,
      rating: 4.3,
      discount: '40% OFF',
      seller: topSellers[1]
    },
    {
      id: 6,
      name: 'Scientific Calculator',
      price: 'GHC 80',
      originalPrice: 'GHC 120',
      location: 'KNUST',
      image: 'https://images.unsplash.com/photo-1574607383476-f517f260d30b?w=400',
      verified: true,
      sold: 23,
      rating: 4.6,
      discount: '33% OFF',
      seller: topSellers[2]
    }
  ]
};

function App() {
  const [activeTab, setActiveTab] = useState('Top Products');
  const [currentBannerIndex, setCurrentBannerIndex] = useState(0);
  const [products, setProducts] = useState(allProducts[activeTab]);
  const [loading, setLoading] = useState(false);
  const [loadCount, setLoadCount] = useState(0);
  const [isGridView, setIsGridView] = useState(true);
  const [showFilters, setShowFilters] = useState(false);
  const [selectedLocation, setSelectedLocation] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [priceRange, setPriceRange] = useState({ min: '', max: '' });
  
  const tabs = ['Top Products', 'Best Sellers', 'Promos & Disc'];

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentBannerIndex((prev) => (prev + 1) % banners.length);
    }, 3000);
    return () => clearInterval(timer);
  }, []);

  const handleScroll = (e) => {
    const bottom = Math.ceil(window.innerHeight + window.scrollY) >= document.documentElement.scrollHeight;
    
    if (bottom && !loading) {
      setLoading(true);
      setTimeout(() => {
        setLoadCount(prev => prev + 1);
        const newProducts = allProducts[activeTab].map(product => ({
          ...product,
          id: product.id + (loadCount + 1) * 100
        }));
        setProducts(prev => [...prev, ...newProducts]);
        setLoading(false);
      }, 1000);
    }
  };

  useEffect(() => {
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, [loading, activeTab, loadCount]);

  useEffect(() => {
    setProducts(allProducts[activeTab]);
    setLoadCount(0);
  }, [activeTab]);

  return (
    <div className="min-h-screen bg-gray-100 pb-20">
      <header className="bg-white sticky top-0 z-50 shadow-sm">
        <div className="container mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            <select className="border rounded-md px-2 py-1">
              {locations.map(loc => (
                <option key={loc}>{loc}</option>
              ))}
            </select>
            
            <div className="flex-1 mx-4">
              <div className="relative">
                <input
                  type="text"
                  placeholder="Search products..."
                  className="w-full pl-10 pr-4 py-2 border rounded-lg"
                />
                <Search className="w-5 h-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <Camera className="w-5 h-5 absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              </div>
            </div>
            
            <div className="flex items-center gap-4">
              <Bell className="w-6 h-6" />
              <ShoppingCart className="w-6 h-6" />
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6">
        {/* Banner */}
        <div className="relative h-64 rounded-lg overflow-hidden mb-8">
          <img
            src={banners[currentBannerIndex].image}
            alt={banners[currentBannerIndex].title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-black bg-opacity-40 flex flex-col items-center justify-center text-white">
            <h1 className="text-3xl font-bold mb-2">{banners[currentBannerIndex].title}</h1>
            <p className="mb-4">{banners[currentBannerIndex].subtitle}</p>
            <div className="flex gap-4">
              <button className="bg-blue-500 text-white px-8 py-2 rounded-md hover:bg-blue-600 transition-colors">
                BUY
              </button>
              <button className="bg-green-500 text-white px-8 py-2 rounded-md hover:bg-green-600 transition-colors">
                SELL
              </button>
            </div>
          </div>
          <div className="absolute bottom-4 left-0 right-0 flex justify-center gap-2">
            {banners.map((_, index) => (
              <div
                key={index}
                className={`w-2 h-2 rounded-full ${
                  currentBannerIndex === index ? 'bg-white' : 'bg-white/50'
                }`}
              />
            ))}
          </div>
        </div>

        {/* Categories */}
        <div className="mb-8">
          <h2 className="text-xl font-semibold mb-4">Categories</h2>
          <div className="grid grid-cols-5 gap-4">
            {categories.map((category) => {
              const Icon = category.icon;
              return (
                <div key={category.name} className="flex flex-col items-center">
                  <div className={`w-16 h-16 ${category.color} rounded-lg mb-2 flex items-center justify-center`}>
                    <Icon className="w-8 h-8 text-white" />
                  </div>
                  <p className="text-center text-sm">{category.name}</p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Top Sellers Section (Only show in Best Sellers tab) */}
        {activeTab === 'Best Sellers' && (
          <div className="mb-8">
            <h2 className="text-xl font-semibold mb-4">Top Sellers</h2>
            <div className="flex gap-4 overflow-x-auto pb-4">
              {topSellers.map((seller) => (
                <div key={seller.id} className="flex-shrink-0 bg-white p-4 rounded-lg shadow-sm">
                  <div className="flex items-center gap-3">
                    <img src={seller.avatar} alt={seller.name} className="w-12 h-12 rounded-full" />
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="font-medium">{seller.name}</h3>
                        {seller.verified && (
                          <span className="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded-full">
                            Verified
                          </span>
                        )}
                      </div>
                      <p className="text-sm text-gray-500">{seller.location}</p>
                      <div className="flex items-center gap-2 text-sm">
                        <span className="text-yellow-500">★ {seller.rating}</span>
                        <span className="text-gray-500">•</span>
                        <span className="text-gray-500">{seller.sales} sales</span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Sticky Tabs */}
        <div className="sticky top-16 bg-gray-100 z-40 -mx-4 px-4 py-2">
          <div className="flex gap-6 border-b bg-gray-100">
            {tabs.map((tab) => (
              <button
                key={tab}
                className={`pb-2 px-1 ${
                  activeTab === tab
                    ? 'border-b-2 border-green-500 text-green-500'
                    : 'text-gray-500'
                }`}
                onClick={() => setActiveTab(tab)}
              >
                {tab}
              </button>
            ))}
          </div>
        </div>

        {/* Filter Panel */}
        {showFilters && (
          <div className="bg-white p-4 rounded-lg shadow-lg mb-4">
            <h3 className="font-semibold mb-4">Filters</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Location</label>
                <select
                  className="w-full border rounded-md p-2"
                  value={selectedLocation}
                  onChange={(e) => setSelectedLocation(e.target.value)}
                >
                  <option value="">All Locations</option>
                  {locations.map(loc => (
                    <option key={loc} value={loc}>{loc}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Category</label>
                <select
                  className="w-full border rounded-md p-2"
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                >
                  <option value="">All Categories</option>
                  {categories.map(cat => (
                    <option key={cat.name} value={cat.name}>{cat.name}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Price Range</label>
                <div className="flex gap-2">
                  <input
                    type="number"
                    placeholder="Min"
                    className="w-1/2 border rounded-md p-2"
                    value={priceRange.min}
                    onChange={(e) => setPriceRange(prev => ({ ...prev, min: e.target.value }))}
                  />
                  <input
                    type="number"
                    placeholder="Max"
                    className="w-1/2 border rounded-md p-2"
                    value={priceRange.max}
                    onChange={(e) => setPriceRange(prev => ({ ...prev, max: e.target.value }))}
                  />
                </div>
              </div>
              <button className="w-full bg-green-500 text-white py-2 rounded-md hover:bg-green-600">
                Apply Filters
              </button>
            </div>
          </div>
        )}

        {/* Products Grid/List */}
        <div className={isGridView ? "grid grid-cols-2 gap-4 mt-6" : "space-y-4 mt-6"}>
          {products.map((product) => (
            <div key={product.id} className={`bg-white rounded-lg p-4 shadow-sm ${!isGridView && 'flex gap-4'}`}>
              <img
                src={product.image}
                alt={product.name}
                className={`${isGridView ? 'w-full h-48' : 'w-32 h-32'} object-cover rounded-lg`}
              />
              <div className="space-y-2 flex-1">
                <h3 className="font-medium">{product.name}</h3>
                <div className="flex items-center justify-between text-sm">
                  <div>
                    <span className="font-bold">{product.price}</span>
                    {product.originalPrice && (
                      <span className="text-gray-400 line-through ml-2 text-xs">
                        {product.originalPrice}
                      </span>
                    )}
                  </div>
                  <span className="text-gray-500">{product.location}</span>
                </div>
                {product.seller && (
                  <div className="flex items-center gap-2 mt-2">
                    <img src={product.seller.avatar} alt={product.seller.name} className="w-6 h-6 rounded-full" />
                    <span className="text-sm text-gray-600">{product.seller.name}</span>
                    {product.seller.verified && (
                      <span className="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded-full">
                        Verified
                      </span>
                    )}
                  </div>
                )}
                <div className="flex items-center gap-2 text-sm flex-wrap">
                  {product.verified && (
                    <span className="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs">
                      Verified
                    </span>
                  )}
                  {product.discount && (
                    <span className="bg-red-100 text-red-800 px-2 py-1 rounded-full text-xs">
                      {product.discount}
                    </span>
                  )}
                  <span className="text-gray-500">{product.sold} Sold</span>
                  <span className="text-yellow-500">★ {product.rating}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        {loading && (
          <div className="text-center py-4">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900 mx-auto"></div>
          </div>
        )}
      </main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-white border-t py-3">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center">
            <button className="flex flex-col items-center gap-1">
              <Home className="w-6 h-6" />
              <span className="text-xs">Home</span>
            </button>
            <button className="flex flex-col items-center gap-1">
              <Compass className="w-6 h-6" />
              <span className="text-xs">Explore</span>
            </button>
            <button className="flex flex-col items-center gap-1">
              <Swipe className="w-6 h-6" />
              <span className="text-xs">Swipe</span>
            </button>
            <button className="flex flex-col items-center gap-1">
              <MessageSquare className="w-6 h-6" />
              <span className="text-xs">Messages</span>
            </button>
            <button className="flex flex-col items-center gap-1">
              <User className="w-6 h-6" />
              <span className="text-xs">Profile</span>
            </button>
          </div>
        </div>
      </nav>

      {/* Back to Top Button */}
      <button 
        className="fixed bottom-20 right-4 bg-white p-2 rounded-full shadow-lg"
        onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
      >
        <ArrowUp className="w-6 h-6" />
      </button>

      {/* Filter and Grid View Buttons */}
      <div className="fixed bottom-20 left-4 space-x-2">
        <button 
          className="bg-white p-2 rounded-full shadow-lg"
          onClick={() => setShowFilters(!showFilters)}
        >
          <Filter className="w-6 h-6" />
        </button>
        <button 
          className="bg-white p-2 rounded-full shadow-lg"
          onClick={() => setIsGridView(!isGridView)}
        >
          <Grid className="w-6 h-6" />
        </button>
      </div>
    </div>
  );
}

export default App;